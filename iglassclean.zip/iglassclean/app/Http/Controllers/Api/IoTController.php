<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\SensorLog;
use App\Models\ActivityLog;
use App\Models\Schedule;
use App\Models\Setting;
use Illuminate\Http\Request;

class IoTController extends Controller
{
    /**
     * Log sensor data from ESP32
     * POST /api/log_sensor.php compatible
     */
    public function logSensor(Request $request)
    {
        $validated = $request->validate([
            'rain_value' => 'required|integer',
            'rain_status' => 'required|string|max:50',
            'servo_status' => 'required|string|max:10',
        ]);

        $log = SensorLog::create($validated);

        return response()->json([
            'success' => true,
            'message' => 'Sensor data logged',
            'id' => $log->id,
        ]);
    }

    /**
     * Log activity from ESP32
     * POST /api/log_activity.php compatible
     */
    public function logActivity(Request $request)
    {
        $validated = $request->validate([
            'action' => 'required|string|max:100',
            'details' => 'nullable|string',
            'source' => 'nullable|string|max:50',
        ]);

        $log = ActivityLog::create([
            'action' => $validated['action'],
            'details' => $validated['details'] ?? null,
            'source' => $validated['source'] ?? 'esp32',
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Activity logged',
            'id' => $log->id,
        ]);
    }

    /**
     * Get current settings
     */
    public function getSettings()
    {
        return response()->json([
            'speed' => Setting::get('servo_speed', 15),
            'mode' => Setting::get('mode', 'auto'),
        ]);
    }

    /**
     * Update settings
     */
    public function updateSettings(Request $request)
    {
        if ($request->has('speed')) {
            Setting::set('servo_speed', $request->input('speed'));
        }

        if ($request->has('mode')) {
            Setting::set('mode', $request->input('mode'));
        }

        return response()->json([
            'success' => true,
            'message' => 'Settings updated',
        ]);
    }

    /**
     * Get pending schedules
     */
    public function getPendingSchedules()
    {
        $schedules = Schedule::where('status', 'pending')
            ->where('scheduled_date', '>=', now()->toDateString())
            ->orderBy('scheduled_date')
            ->orderBy('scheduled_time')
            ->get()
            ->map(function ($schedule) {
                return [
                    'id' => $schedule->id,
                    'date' => $schedule->scheduled_date->format('d/m/Y'),
                    'time' => $schedule->scheduled_time->format('H:i'),
                    'duration' => $schedule->duration_minutes,
                    'mqtt_format' => $schedule->toMqttFormat(),
                ];
            });

        return response()->json($schedules);
    }

    /**
     * Create a new schedule
     */
    public function createSchedule(Request $request)
    {
        $validated = $request->validate([
            'scheduled_date' => 'required|date|after_or_equal:today',
            'scheduled_time' => 'required|date_format:H:i',
            'duration_minutes' => 'required|integer|min:1|max:60',
        ]);

        $schedule = Schedule::create($validated);

        // Log activity
        ActivityLog::create([
            'action' => 'SCHEDULE_SET',
            'details' => "Schedule created: {$schedule->scheduled_date->format('d/m/Y')} {$schedule->scheduled_time->format('H:i')}",
            'source' => 'web',
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Schedule created',
            'schedule' => $schedule,
        ]);
    }

    /**
     * Update schedule status
     */
    public function updateScheduleStatus(Request $request, Schedule $schedule)
    {
        $validated = $request->validate([
            'status' => 'required|in:pending,triggered,completed,cancelled',
        ]);

        $schedule->update($validated);

        return response()->json([
            'success' => true,
            'message' => 'Schedule status updated',
        ]);
    }
}
