<?php

namespace App\Http\Controllers;

use App\Models\SensorLog;
use App\Models\ActivityLog;
use App\Models\Schedule;
use App\Models\Setting;
use Illuminate\Http\Request;
use Carbon\Carbon;

class DashboardController extends Controller
{
    /**
     * Display the dashboard
     */
    public function index()
    {
        // Get latest sensor data
        $latestSensor = SensorLog::latest('created_at')->first();

        // Get recent activity logs
        $recentActivities = ActivityLog::latest('created_at')
            ->take(10)
            ->get();

        // Get pending schedules
        $pendingSchedules = Schedule::where('status', 'pending')
            ->where('schedule_date', '>=', now()->toDateString())
            ->orderBy('schedule_date')
            ->orderBy('schedule_time')
            ->get();

        // Get statistics
        $stats = $this->getStatistics();

        // Prepare initial sensor data for JavaScript
        $initialSensorData = [
            'rain_value' => $latestSensor->rain_value ?? 0,
            'rain_status' => $latestSensor->rain_status ?? 'TIDAK_HUJAN',
            'rain_status_label' => $latestSensor->rain_status_label ?? 'Tidak Hujan',
            'rain_intensity' => $latestSensor->rain_intensity ?? 0,
            'servo_status' => $latestSensor->servo_status ?? 'OFF',
            'created_at' => $latestSensor?->created_at?->format('H:i:s') ?? '-',
        ];

        // API routes for JavaScript
        $apiRoutes = [
            'realtime' => route('api.realtime'),
            'chart' => route('api.chart'),
        ];

        return view('dashboard.index', compact(
            'latestSensor',
            'recentActivities',
            'pendingSchedules',
            'stats',
            'initialSensorData',
            'apiRoutes'
        ));
    }

    /**
     * Get sensor history
     */
    public function sensorHistory(Request $request)
    {
        $date = $request->get('date', now()->toDateString());

        $logs = SensorLog::whereDate('created_at', $date)
            ->orderBy('created_at', 'desc')
            ->paginate(50);

        return view('dashboard.sensor-history', compact('logs', 'date'));
    }

    /**
     * Get activity history
     */
    public function activityHistory(Request $request)
    {
        $date = $request->get('date', now()->toDateString());

        $logs = ActivityLog::whereDate('created_at', $date)
            ->orderBy('created_at', 'desc')
            ->paginate(50);

        return view('dashboard.activity-history', compact('logs', 'date'));
    }

    /**
     * Get schedule list
     */
    public function schedules()
    {
        $schedules = Schedule::orderBy('schedule_date', 'desc')
            ->orderBy('schedule_time', 'desc')
            ->paginate(20);

        return view('dashboard.schedules', compact('schedules'));
    }

    /**
     * Get statistics
     */
    private function getStatistics(): array
    {
        $today = now()->toDateString();

        // Today's sensor readings
        $todaySensorCount = SensorLog::whereDate('created_at', $today)->count();

        // Today's activities
        $todayActivityCount = ActivityLog::whereDate('created_at', $today)->count();

        // Rain statistics for today
        $rainStats = SensorLog::whereDate('created_at', $today)
            ->selectRaw('rain_status, COUNT(*) as count')
            ->groupBy('rain_status')
            ->pluck('count', 'rain_status')
            ->toArray();

        // Servo ON time today
        $servoOnCount = SensorLog::whereDate('created_at', $today)
            ->where('servo_status', 'ON')
            ->count();

        // Calculate approximate servo running time (each log is 10 seconds apart)
        $servoRunningMinutes = round(($servoOnCount * 10) / 60, 1);

        // Last 7 days sensor data for chart
        $last7Days = [];
        for ($i = 6; $i >= 0; $i--) {
            $date = now()->subDays($i)->toDateString();
            $dayStats = SensorLog::whereDate('created_at', $date)
                ->selectRaw('AVG(rain_value) as avg_rain, 
                            SUM(CASE WHEN servo_status = "ON" THEN 1 ELSE 0 END) as servo_on_count')
                ->first();

            $last7Days[] = [
                'date' => Carbon::parse($date)->format('d M'),
                'avg_rain' => round($dayStats->avg_rain ?? 0),
                'servo_minutes' => round((($dayStats->servo_on_count ?? 0) * 10) / 60, 1),
            ];
        }

        return [
            'today_sensor_count' => $todaySensorCount,
            'today_activity_count' => $todayActivityCount,
            'rain_stats' => $rainStats,
            'servo_running_minutes' => $servoRunningMinutes,
            'last_7_days' => $last7Days,
        ];
    }

    /**
     * API endpoint to get real-time data
     */
    public function apiRealtime()
    {
        $latestSensor = SensorLog::latest('created_at')->first();
        $latestActivity = ActivityLog::latest('created_at')->first();

        return response()->json([
            'sensor' => $latestSensor ? [
                'rain_value' => $latestSensor->rain_value,
                'rain_status' => $latestSensor->rain_status,
                'rain_status_label' => $latestSensor->rain_status_label,
                'rain_intensity' => $latestSensor->rain_intensity,
                'rain_status_color' => $latestSensor->rain_status_color,
                'servo_status' => $latestSensor->servo_status,
                'created_at' => $latestSensor->created_at->format('H:i:s'),
            ] : null,
            'latest_activity' => $latestActivity ? [
                'action' => $latestActivity->action,
                'action_label' => $latestActivity->action_label,
                'details' => $latestActivity->details,
                'created_at' => $latestActivity->created_at->format('H:i:s'),
            ] : null,
            'timestamp' => now()->format('Y-m-d H:i:s'),
        ]);
    }

    /**
     * API endpoint to get chart data
     */
    public function apiChartData(Request $request)
    {
        $hours = $request->get('hours', 1);
        $startTime = now()->subHours($hours);

        $data = SensorLog::where('created_at', '>=', $startTime)
            ->orderBy('created_at')
            ->get()
            ->map(function ($log) {
                return [
                    'time' => $log->created_at->format('H:i:s'),
                    'rain_value' => $log->rain_value,
                    'servo_status' => $log->servo_status === 'ON' ? 1 : 0,
                ];
            });

        return response()->json($data);
    }
}
