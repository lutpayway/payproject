<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;

class Schedule extends Model
{
    public $timestamps = false;

    const CREATED_AT = 'created_at';

    protected $fillable = [
        'schedule_date',
        'schedule_time',
        'duration_minutes',
        'status',
        'triggered_at',
    ];

    protected $casts = [
        'schedule_date' => 'date',
        'created_at' => 'datetime',
        'triggered_at' => 'datetime',
    ];

    public function getScheduleTimeFormattedAttribute(): string
    {
        return Carbon::parse($this->schedule_time)->format('H:i');
    }

    public function getStatusLabelAttribute(): string
    {
        return match ($this->status) {
            'pending' => 'Menunggu',
            'triggered' => 'Berjalan',
            'completed' => 'Selesai',
            'cancelled' => 'Dibatalkan',
            default => $this->status ?? 'Menunggu',
        };
    }

    public function getStatusColorAttribute(): string
    {
        return match ($this->status) {
            'pending' => 'yellow',
            'triggered' => 'blue',
            'completed' => 'green',
            'cancelled' => 'red',
            default => 'gray',
        };
    }

    public function toMqttFormat(): string
    {
        $date = $this->schedule_date->format('d/m/Y');
        $time = Carbon::parse($this->schedule_time)->format('H:i');
        return "{$date},{$time},{$this->duration_minutes}";
    }
}
