<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SensorLog extends Model
{
    public $timestamps = false;

    protected $fillable = [
        'rain_value',
        'rain_status',
        'servo_status',
    ];

    protected $casts = [
        'created_at' => 'datetime',
    ];

    /**
     * Get rain intensity percentage (0-100)
     */
    public function getRainIntensityAttribute(): int
    {
        // Based on Arduino code: < 1500 = DERAS (heavy), < 3000 = SEDANG (medium), else = TIDAK_HUJAN
        if ($this->rain_value < 1500) {
            return 100 - (int)(($this->rain_value / 1500) * 33);
        } elseif ($this->rain_value < 3000) {
            return 66 - (int)((($this->rain_value - 1500) / 1500) * 33);
        }
        return max(0, 33 - (int)((($this->rain_value - 3000) / 1095) * 33));
    }

    /**
     * Get translated rain status
     */
    public function getRainStatusLabelAttribute(): string
    {
        return match ($this->rain_status) {
            'DERAS' => 'Hujan Deras',
            'SEDANG' => 'Hujan Sedang',
            'TIDAK_HUJAN' => 'Tidak Hujan',
            default => $this->rain_status,
        };
    }

    /**
     * Get status color class
     */
    public function getRainStatusColorAttribute(): string
    {
        return match ($this->rain_status) {
            'DERAS' => 'red',
            'SEDANG' => 'yellow',
            'TIDAK_HUJAN' => 'green',
            default => 'gray',
        };
    }
}
