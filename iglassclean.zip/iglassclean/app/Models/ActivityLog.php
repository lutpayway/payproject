<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ActivityLog extends Model
{
    public $timestamps = false;

    protected $fillable = [
        'action',
        'details',
        'source',
    ];

    protected $casts = [
        'created_at' => 'datetime',
    ];

    /**
     * Get action icon
     */
    public function getActionIconAttribute(): string
    {
        return match (true) {
            str_contains($this->action, 'SERVO_ON') => 'play-circle',
            str_contains($this->action, 'SERVO_OFF') => 'stop-circle',
            str_contains($this->action, 'MANUAL') => 'hand-raised',
            str_contains($this->action, 'SCHEDULE') => 'calendar',
            str_contains($this->action, 'DEMO') => 'beaker',
            str_contains($this->action, 'SPEED') => 'adjustments-horizontal',
            str_contains($this->action, 'RAIN') => 'cloud-rain',
            str_contains($this->action, 'BOOT') => 'power',
            default => 'information-circle',
        };
    }

    /**
     * Get action color
     */
    public function getActionColorAttribute(): string
    {
        return match (true) {
            str_contains($this->action, 'ON') || str_contains($this->action, 'TRIGGERED') => 'green',
            str_contains($this->action, 'OFF') || str_contains($this->action, 'CLEAR') => 'red',
            str_contains($this->action, 'SET') || str_contains($this->action, 'CHANGE') => 'blue',
            str_contains($this->action, 'BOOT') => 'purple',
            str_contains($this->action, 'COMPLETED') => 'indigo',
            default => 'gray',
        };
    }

    /**
     * Get formatted action label
     */
    public function getActionLabelAttribute(): string
    {
        return match ($this->action) {
            'SERVO_ON' => 'Servo Aktif',
            'SERVO_OFF' => 'Servo Mati',
            'MANUAL_ON' => 'Mode Manual Aktif',
            'MANUAL_OFF' => 'Mode Manual Mati',
            'DEMO_ON' => 'Mode Demo Aktif',
            'DEMO_OFF' => 'Mode Demo Mati',
            'SCHEDULE_SET' => 'Jadwal Dibuat',
            'SCHEDULE_TRIGGERED' => 'Jadwal Dijalankan',
            'SCHEDULE_COMPLETED' => 'Jadwal Selesai',
            'SCHEDULE_CLEAR' => 'Jadwal Dihapus',
            'SPEED_CHANGE' => 'Kecepatan Diubah',
            'AUTO_RAIN_ON' => 'Auto Hujan Aktif',
            'AUTO_RAIN_OFF' => 'Auto Hujan Mati',
            'BOOT' => 'Sistem Mulai',
            default => $this->action,
        };
    }
}
