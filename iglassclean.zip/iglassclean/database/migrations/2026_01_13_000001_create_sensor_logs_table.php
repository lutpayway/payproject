<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        if (Schema::hasTable('sensor_logs')) {
            return;
        }
        Schema::create('sensor_logs', function (Blueprint $table) {
            $table->id();
            $table->integer('rain_value');
            $table->string('rain_status', 50);
            $table->string('servo_status', 10);
            $table->timestamp('created_at')->useCurrent();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('sensor_logs');
    }
};
