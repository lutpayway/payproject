// Dashboard Data for Alpine.js
function dashboardData() {
    // Read config from HTML element
    var configEl = document.getElementById('dashboard-config');
    var initialSensor = configEl ? JSON.parse(configEl.dataset.sensor || '{}') : {};
    var weeklyData = configEl ? JSON.parse(configEl.dataset.weekly || '[]') : [];
    var apiRealtime = configEl ? configEl.dataset.apiRealtime : '';
    var apiChart = configEl ? configEl.dataset.apiChart : '';

    return {
        sensor: {
            rain_value: initialSensor.rain_value || 0,
            rain_status: initialSensor.rain_status || 'TIDAK_HUJAN',
            rain_status_label: initialSensor.rain_status_label || 'Tidak Hujan',
            rain_intensity: initialSensor.rain_intensity || 0,
            servo_status: initialSensor.servo_status || 'OFF',
            created_at: initialSensor.created_at || '-'
        },
        chartHours: 1,
        sensorChart: null,
        weeklyChart: null,
        weeklyData: weeklyData,
        apiRealtime: apiRealtime,
        apiChart: apiChart,

        init: function() {
            var self = this;
            // Wait for Chart.js to be ready
            setTimeout(function() {
                self.initWeeklyChart();
                self.loadChartData(1);
                self.startPolling();
            }, 100);
        },

        startPolling: function() {
            var self = this;
            setInterval(function() {
                self.fetchRealtimeData();
            }, 5000);
        },

        fetchRealtimeData: function() {
            var self = this;
            if (!this.apiRealtime) return;
            
            fetch(this.apiRealtime)
                .then(function(response) { return response.json(); })
                .then(function(data) {
                    if (data.sensor) {
                        self.sensor = data.sensor;
                    }
                })
                .catch(function(error) {
                    console.error('Error fetching realtime data:', error);
                });
        },

        loadChartData: function(hours) {
            var self = this;
            this.chartHours = hours;
            if (!this.apiChart) return;

            fetch(this.apiChart + '?hours=' + hours)
                .then(function(response) { return response.json(); })
                .then(function(data) {
                    self.updateSensorChart(data);
                })
                .catch(function(error) {
                    console.error('Error loading chart data:', error);
                });
        },

        updateSensorChart: function(data) {
            var canvas = document.getElementById('sensorChart');
            if (!canvas) return;
            
            var ctx = canvas.getContext('2d');

            if (this.sensorChart) {
                this.sensorChart.destroy();
            }

            this.sensorChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: data.map(function(d) { return d.time; }),
                    datasets: [{
                        label: 'Nilai Sensor Hujan',
                        data: data.map(function(d) { return d.rain_value; }),
                        borderColor: 'rgb(99, 102, 241)',
                        backgroundColor: 'rgba(99, 102, 241, 0.1)',
                        fill: true,
                        tension: 0.4,
                        pointRadius: 0,
                        borderWidth: 2
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: { legend: { display: false } },
                    scales: {
                        x: { display: true, grid: { display: false }, ticks: { maxTicksLimit: 8, font: { size: 10 } } },
                        y: { display: true, min: 0, max: 4095, grid: { color: 'rgba(0, 0, 0, 0.05)' }, ticks: { font: { size: 10 } } }
                    },
                    interaction: { intersect: false, mode: 'index' }
                }
            });
        },

        initWeeklyChart: function() {
            var canvas = document.getElementById('weeklyChart');
            if (!canvas) return;
            
            var ctx = canvas.getContext('2d');

            this.weeklyChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: this.weeklyData.map(function(d) { return d.date; }),
                    datasets: [{
                        label: 'Wiper Aktif (menit)',
                        data: this.weeklyData.map(function(d) { return d.servo_minutes; }),
                        backgroundColor: 'rgba(99, 102, 241, 0.8)',
                        borderRadius: 8,
                        barThickness: 24
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: { legend: { display: false } },
                    scales: {
                        x: { grid: { display: false } },
                        y: {
                            beginAtZero: true,
                            grid: { color: 'rgba(0, 0, 0, 0.05)' },
                            ticks: { callback: function(value) { return value + ' mnt'; } }
                        }
                    }
                }
            });
        }
    };
}
