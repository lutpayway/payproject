<?php

/**
 * API endpoint for ESP32 activity logging
 * Standalone PHP - no Laravel dependency
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

// Database config
$host = '127.0.0.1';
$dbname = 'wiper_iot';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $action = isset($_POST['action']) ? $_POST['action'] : 'UNKNOWN';
    $details = isset($_POST['details']) ? $_POST['details'] : '';
    $source = isset($_POST['source']) ? $_POST['source'] : 'esp32';

    $stmt = $pdo->prepare("INSERT INTO activity_logs (action, details, source, created_at) VALUES (?, ?, ?, NOW())");
    $stmt->execute([$action, $details, $source]);

    echo json_encode([
        'success' => true,
        'message' => 'Activity logged',
        'id' => $pdo->lastInsertId()
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
