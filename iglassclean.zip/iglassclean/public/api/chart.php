<?php

/**
 * API endpoint for chart data
 * Standalone PHP - no Laravel dependency
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

// Database config
$host = '127.0.0.1';
$dbname = 'wiper_iot';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $hours = isset($_GET['hours']) ? (int)$_GET['hours'] : 1;
    $startTime = date('Y-m-d H:i:s', strtotime("-{$hours} hours"));

    $stmt = $pdo->prepare("SELECT rain_value, servo_status, created_at FROM sensor_logs WHERE created_at >= ? ORDER BY created_at ASC");
    $stmt->execute([$startTime]);
    $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $data = [];
    foreach ($logs as $log) {
        $data[] = [
            'time' => date('H:i:s', strtotime($log['created_at'])),
            'rain_value' => (int)$log['rain_value'],
            'servo_status' => $log['servo_status'] === 'ON' ? 1 : 0
        ];
    }

    echo json_encode($data);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
