<?php

/**
 * API endpoint for real-time sensor data
 * Standalone PHP - no Laravel dependency
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

// Database config
$host = '127.0.0.1';
$dbname = 'wiper_iot';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Get latest sensor data
    $stmt = $pdo->query("SELECT * FROM sensor_logs ORDER BY created_at DESC LIMIT 1");
    $sensor = $stmt->fetch(PDO::FETCH_ASSOC);

    // Get latest activity
    $stmt2 = $pdo->query("SELECT * FROM activity_logs ORDER BY created_at DESC LIMIT 1");
    $activity = $stmt2->fetch(PDO::FETCH_ASSOC);

    // Helper function for rain status
    function getRainStatusLabel($status)
    {
        $labels = [
            'DERAS' => 'Hujan Deras',
            'SEDANG' => 'Hujan Sedang',
            'TIDAK_HUJAN' => 'Tidak Hujan'
        ];
        return $labels[$status] ?? 'Tidak Diketahui';
    }

    function getRainStatusColor($status)
    {
        $colors = [
            'DERAS' => 'red',
            'SEDANG' => 'yellow',
            'TIDAK_HUJAN' => 'green'
        ];
        return $colors[$status] ?? 'gray';
    }

    function getRainIntensity($value)
    {
        return round((4095 - $value) / 4095 * 100);
    }

    function getActionLabel($action)
    {
        $labels = [
            'SERVO_ON' => 'Servo Aktif',
            'SERVO_OFF' => 'Servo Mati',
            'MANUAL_ON' => 'Mode Manual Aktif',
            'MANUAL_OFF' => 'Mode Manual Mati',
            'DEMO_ON' => 'Mode Demo Aktif',
            'DEMO_OFF' => 'Mode Demo Mati',
            'SCHEDULE_SET' => 'Jadwal Diatur',
            'SCHEDULE_TRIGGERED' => 'Jadwal Dieksekusi',
            'SCHEDULE_COMPLETED' => 'Jadwal Selesai',
            'AUTO_RAIN_ON' => 'Deteksi Hujan Aktif',
            'AUTO_RAIN_OFF' => 'Auto Hujan Mati',
            'BOOT' => 'Sistem Boot'
        ];
        return $labels[$action] ?? $action;
    }

    $response = [
        'sensor' => $sensor ? [
            'rain_value' => (int)$sensor['rain_value'],
            'rain_status' => $sensor['rain_status'],
            'rain_status_label' => getRainStatusLabel($sensor['rain_status']),
            'rain_intensity' => getRainIntensity($sensor['rain_value']),
            'rain_status_color' => getRainStatusColor($sensor['rain_status']),
            'servo_status' => $sensor['servo_status'],
            'created_at' => date('H:i:s', strtotime($sensor['created_at']))
        ] : null,
        'latest_activity' => $activity ? [
            'action' => $activity['action'],
            'action_label' => getActionLabel($activity['action']),
            'details' => $activity['details'],
            'created_at' => date('H:i:s', strtotime($activity['created_at']))
        ] : null,
        'timestamp' => date('Y-m-d H:i:s')
    ];

    echo json_encode($response);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
