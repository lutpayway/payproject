<?php

/**
 * API endpoint for ESP32 sensor logging
 * Standalone PHP - no Laravel dependency
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

// Database config
$host = '127.0.0.1';
$dbname = 'wiper_iot';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $rain_value = isset($_POST['rain_value']) ? (int)$_POST['rain_value'] : 0;
    $rain_status = isset($_POST['rain_status']) ? $_POST['rain_status'] : 'TIDAK_HUJAN';
    $servo_status = isset($_POST['servo_status']) ? $_POST['servo_status'] : 'OFF';

    $stmt = $pdo->prepare("INSERT INTO sensor_logs (rain_value, rain_status, servo_status, created_at) VALUES (?, ?, ?, NOW())");
    $stmt->execute([$rain_value, $rain_status, $servo_status]);

    echo json_encode([
        'success' => true,
        'message' => 'Sensor data logged',
        'id' => $pdo->lastInsertId()
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
