<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Database connection
$host = 'localhost';
$dbname = 'wiper_iot';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo json_encode(['error' => 'Database connection failed']);
    exit();
}

// GET - Fetch statistics
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $today = date('Y-m-d');

    // Total sensor readings today
    $sqlReadings = "SELECT COUNT(*) as total FROM sensor_logs WHERE DATE(created_at) = :today";
    $stmtReadings = $pdo->prepare($sqlReadings);
    $stmtReadings->bindValue(':today', $today);
    $stmtReadings->execute();
    $totalReadings = $stmtReadings->fetch(PDO::FETCH_ASSOC)['total'];

    // Count wiper ON activities today
    $sqlActive = "SELECT COUNT(*) as total FROM activity_logs 
                  WHERE DATE(created_at) = :today 
                  AND (action LIKE '%ON%' OR action LIKE '%ACTIVATED%' OR action LIKE '%START%')";
    $stmtActive = $pdo->prepare($sqlActive);
    $stmtActive->bindValue(':today', $today);
    $stmtActive->execute();
    $activeCount = $stmtActive->fetch(PDO::FETCH_ASSOC)['total'];

    // Estimate active minutes (assume average 2 minutes per activation)
    $activeMinutes = $activeCount * 2;

    // Alternative: Calculate from sensor logs where servo was ON
    $sqlServoActive = "SELECT COUNT(*) as total FROM sensor_logs 
                       WHERE DATE(created_at) = :today 
                       AND (servo_status = 'ON' OR servo_status = '1')";
    $stmtServo = $pdo->prepare($sqlServoActive);
    $stmtServo->bindValue(':today', $today);
    $stmtServo->execute();
    $servoActiveCount = $stmtServo->fetch(PDO::FETCH_ASSOC)['total'];

    // If we have servo data, calculate more accurately (assuming 5 second intervals)
    if ($servoActiveCount > 0) {
        $activeMinutes = round($servoActiveCount * 5 / 60); // Convert to minutes
    }

    // Recent activity
    $sqlRecent = "SELECT action, details, created_at 
                  FROM activity_logs 
                  ORDER BY created_at DESC 
                  LIMIT 5";
    $stmtRecent = $pdo->prepare($sqlRecent);
    $stmtRecent->execute();
    $recentActivities = $stmtRecent->fetchAll(PDO::FETCH_ASSOC);

    // Get latest sensor data
    $sqlLatest = "SELECT rain_value, rain_status, servo_status, created_at 
                  FROM sensor_logs 
                  ORDER BY created_at DESC 
                  LIMIT 1";
    $stmtLatest = $pdo->prepare($sqlLatest);
    $stmtLatest->execute();
    $latestSensor = $stmtLatest->fetch(PDO::FETCH_ASSOC);

    echo json_encode([
        'total_readings_today' => (int)$totalReadings,
        'active_minutes_today' => (int)$activeMinutes,
        'recent_activities' => $recentActivities,
        'latest_sensor' => $latestSensor
    ]);
}
