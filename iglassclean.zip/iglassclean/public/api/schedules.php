<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, DELETE, PUT, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Database connection
$host = 'localhost';
$dbname = 'wiper_iot';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo json_encode(['error' => 'Database connection failed']);
    exit();
}

// GET - Fetch all schedules
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $sql = "SELECT id, schedule_date, schedule_time, duration_minutes, status, created_at, triggered_at 
            FROM schedules 
            ORDER BY schedule_date ASC, schedule_time ASC";

    $stmt = $pdo->prepare($sql);
    $stmt->execute();

    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Format data for mobile app
    foreach ($data as &$row) {
        $row['name'] = 'Jadwal ' . date('d/m', strtotime($row['schedule_date']));
        $row['time'] = substr($row['schedule_time'], 0, 5); // HH:MM format
        $row['days'] = [$row['schedule_date']];
        $row['speed'] = (int)$row['duration_minutes'];
        $row['is_active'] = ($row['status'] === 'pending' || $row['status'] === 'triggered');
    }

    echo json_encode(['data' => $data]);
}

// POST - Create new schedule
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);

    if (!$input) {
        echo json_encode(['error' => 'Invalid JSON input']);
        exit();
    }

    // Handle time format
    $time = isset($input['time']) ? $input['time'] : '00:00';

    // Handle days - if array, use first date or today
    $days = isset($input['days']) ? $input['days'] : [];
    if (is_array($days) && count($days) > 0) {
        $firstDay = $days[0];
        if (is_numeric($firstDay)) {
            // Day number (0-6), calculate next occurrence
            $scheduleDate = date('Y-m-d'); // Default today
        } else {
            $scheduleDate = $firstDay;
        }
    } else {
        $scheduleDate = date('Y-m-d'); // Default today
    }

    $duration = isset($input['speed']) ? (int)$input['speed'] : 1;
    $status = 'pending';

    $sql = "INSERT INTO schedules (schedule_date, schedule_time, duration_minutes, status, created_at) 
            VALUES (:schedule_date, :schedule_time, :duration_minutes, :status, NOW())";

    $stmt = $pdo->prepare($sql);
    $stmt->bindValue(':schedule_date', $scheduleDate);
    $stmt->bindValue(':schedule_time', $time);
    $stmt->bindValue(':duration_minutes', $duration, PDO::PARAM_INT);
    $stmt->bindValue(':status', $status);

    if ($stmt->execute()) {
        $id = $pdo->lastInsertId();
        echo json_encode([
            'success' => true,
            'message' => 'Schedule created successfully',
            'id' => (int)$id
        ]);
    } else {
        echo json_encode(['error' => 'Failed to create schedule']);
    }
}

// DELETE - Delete schedule by ID
if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

    if ($id <= 0) {
        echo json_encode(['error' => 'Invalid schedule ID']);
        exit();
    }

    $sql = "DELETE FROM schedules WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->bindValue(':id', $id, PDO::PARAM_INT);

    if ($stmt->execute()) {
        echo json_encode([
            'success' => true,
            'message' => 'Schedule deleted successfully'
        ]);
    } else {
        echo json_encode(['error' => 'Failed to delete schedule']);
    }
}

// PUT - Update schedule
if ($_SERVER['REQUEST_METHOD'] === 'PUT') {
    $input = json_decode(file_get_contents('php://input'), true);

    if (!$input || !isset($input['id'])) {
        echo json_encode(['error' => 'Invalid input or missing ID']);
        exit();
    }

    $id = (int)$input['id'];

    // Toggle status based on is_active
    if (isset($input['is_active'])) {
        $newStatus = $input['is_active'] ? 'pending' : 'cancelled';
        $sql = "UPDATE schedules SET status = :status WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->bindValue(':status', $newStatus);
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);

        if ($stmt->execute()) {
            echo json_encode([
                'success' => true,
                'message' => 'Schedule updated successfully'
            ]);
        } else {
            echo json_encode(['error' => 'Failed to update schedule']);
        }
    }
}
