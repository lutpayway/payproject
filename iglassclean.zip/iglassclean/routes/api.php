<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\IoTController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
*/

// ESP32 compatible endpoints (matching original PHP files)
Route::post('/log_sensor.php', [IoTController::class, 'logSensor']);
Route::post('/log_activity.php', [IoTController::class, 'logActivity']);

// Modern API endpoints
Route::prefix('iot')->group(function () {
    // Sensor
    Route::post('/sensor', [IoTController::class, 'logSensor']);
    Route::post('/activity', [IoTController::class, 'logActivity']);

    // Settings
    Route::get('/settings', [IoTController::class, 'getSettings']);
    Route::post('/settings', [IoTController::class, 'updateSettings']);

    // Schedules
    Route::get('/schedules', [IoTController::class, 'getPendingSchedules']);
    Route::post('/schedules', [IoTController::class, 'createSchedule']);
    Route::put('/schedules/{schedule}/status', [IoTController::class, 'updateScheduleStatus']);
});
