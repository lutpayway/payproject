<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DashboardController;

// Dashboard
Route::get('/', [DashboardController::class, 'index'])->name('dashboard');
Route::get('/sensor-history', [DashboardController::class, 'sensorHistory'])->name('sensor.history');
Route::get('/activity-history', [DashboardController::class, 'activityHistory'])->name('activity.history');
Route::get('/schedules', [DashboardController::class, 'schedules'])->name('schedules');

// Dashboard API (for AJAX)
Route::prefix('api/dashboard')->group(function () {
    Route::get('/realtime', [DashboardController::class, 'apiRealtime'])->name('api.realtime');
    Route::get('/chart', [DashboardController::class, 'apiChartData'])->name('api.chart');
});
