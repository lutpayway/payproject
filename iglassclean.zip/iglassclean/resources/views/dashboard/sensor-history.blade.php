@extends('layouts.app')

@section('title', 'Riwayat Sensor')
@section('page-title', 'Riwayat Sensor')

@section('content')
<div class="space-y-6">

    <!-- Header with date filter -->
    <div class="glass-card rounded-2xl p-6 shadow-lg">
        <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
                <h2 class="text-xl font-semibold text-gray-900">Data Sensor Hujan</h2>
                <p class="text-sm text-gray-500">Riwayat pembacaan sensor dari ESP32</p>
            </div>
            <form method="GET" class="flex items-center gap-3">
                <div class="relative">
                    <input type="date"
                        name="date"
                        value="{{ $date }}"
                        class="pl-10 pr-4 py-2 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all"
                        onchange="this.form.submit()">
                    <i class="fa-regular fa-calendar absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"></i>
                </div>
            </form>
        </div>
    </div>

    <!-- Statistics for selected date -->
    <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">
        @php
        $totalLogs = $logs->total();
        $derasCount = $logs->where('rain_status', 'DERAS')->count();
        $sedangCount = $logs->where('rain_status', 'SEDANG')->count();
        $cerahCount = $logs->where('rain_status', 'TIDAK_HUJAN')->count();
        @endphp

        <div class="glass-card rounded-xl p-4 shadow-md">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-lg bg-purple-100 flex items-center justify-center">
                    <i class="fa-solid fa-database text-purple-600"></i>
                </div>
                <div>
                    <p class="text-2xl font-bold text-gray-900">{{ number_format($totalLogs) }}</p>
                    <p class="text-xs text-gray-500">Total Data</p>
                </div>
            </div>
        </div>

        <div class="glass-card rounded-xl p-4 shadow-md">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-lg bg-red-100 flex items-center justify-center">
                    <i class="fa-solid fa-cloud-showers-heavy text-red-600"></i>
                </div>
                <div>
                    <p class="text-2xl font-bold text-gray-900">{{ $derasCount }}</p>
                    <p class="text-xs text-gray-500">Hujan Deras</p>
                </div>
            </div>
        </div>

        <div class="glass-card rounded-xl p-4 shadow-md">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-lg bg-yellow-100 flex items-center justify-center">
                    <i class="fa-solid fa-cloud-rain text-yellow-600"></i>
                </div>
                <div>
                    <p class="text-2xl font-bold text-gray-900">{{ $sedangCount }}</p>
                    <p class="text-xs text-gray-500">Hujan Sedang</p>
                </div>
            </div>
        </div>

        <div class="glass-card rounded-xl p-4 shadow-md">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-lg bg-green-100 flex items-center justify-center">
                    <i class="fa-solid fa-sun text-green-600"></i>
                </div>
                <div>
                    <p class="text-2xl font-bold text-gray-900">{{ $cerahCount }}</p>
                    <p class="text-xs text-gray-500">Tidak Hujan</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Data Table -->
    <div class="glass-card rounded-2xl shadow-lg overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full">
                <thead>
                    <tr class="bg-gray-50 border-b border-gray-100">
                        <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Waktu</th>
                        <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Nilai Sensor</th>
                        <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Status Hujan</th>
                        <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Intensitas</th>
                        <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Servo</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    @forelse($logs as $log)
                    <tr class="hover:bg-gray-50 transition-colors">
                        <td class="px-6 py-4">
                            <div class="flex items-center gap-2">
                                <i class="fa-regular fa-clock text-gray-400"></i>
                                <span class="text-sm font-medium text-gray-900">{{ $log->created_at->format('H:i:s') }}</span>
                            </div>
                        </td>
                        <td class="px-6 py-4">
                            <span class="text-sm font-semibold text-gray-900">{{ $log->rain_value }}</span>
                            <span class="text-xs text-gray-400">/ 4095</span>
                        </td>
                        <td class="px-6 py-4">
                            <span class="inline-flex items-center gap-1.5 px-3 py-1 text-xs font-medium rounded-full
                                @if($log->rain_status === 'DERAS') bg-red-100 text-red-700
                                @elseif($log->rain_status === 'SEDANG') bg-yellow-100 text-yellow-700
                                @else bg-green-100 text-green-700
                                @endif">
                                @if($log->rain_status === 'DERAS')
                                <i class="fa-solid fa-cloud-showers-heavy"></i>
                                @elseif($log->rain_status === 'SEDANG')
                                <i class="fa-solid fa-cloud-rain"></i>
                                @else
                                <i class="fa-solid fa-sun"></i>
                                @endif
                                {{ $log->rain_status_label }}
                            </span>
                        </td>
                        <td class="px-6 py-4">
                            <div class="w-24">
                                <div class="flex items-center gap-2">
                                    <div class="flex-1 h-2 bg-gray-100 rounded-full overflow-hidden">
                                        <div class="h-full rounded-full
                                            @if($log->rain_status === 'DERAS') bg-red-500
                                            @elseif($log->rain_status === 'SEDANG') bg-yellow-500
                                            @else bg-green-500
                                            @endif"
                                            style="width: {{ $log->rain_intensity }}%">
                                        </div>
                                    </div>
                                    <span class="text-xs text-gray-500">{{ $log->rain_intensity }}%</span>
                                </div>
                            </div>
                        </td>
                        <td class="px-6 py-4">
                            <span class="inline-flex items-center gap-1.5 px-3 py-1 text-xs font-medium rounded-full
                                {{ $log->servo_status === 'ON' ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-600' }}">
                                <i class="fa-solid {{ $log->servo_status === 'ON' ? 'fa-play' : 'fa-stop' }}"></i>
                                {{ $log->servo_status }}
                            </span>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="5" class="px-6 py-12 text-center">
                            <i class="fa-solid fa-inbox text-4xl text-gray-300 mb-3"></i>
                            <p class="text-gray-500">Tidak ada data sensor untuk tanggal ini</p>
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        @if($logs->hasPages())
        <div class="px-6 py-4 border-t border-gray-100">
            {{ $logs->appends(['date' => $date])->links() }}
        </div>
        @endif
    </div>
</div>
@endsection