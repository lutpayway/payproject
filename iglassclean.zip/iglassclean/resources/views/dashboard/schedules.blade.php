@extends('layouts.app')

@section('title', 'Jadwal')
@section('page-title', 'Jadwal Wiper')

@section('content')
<div class="space-y-6">

    <!-- Header -->
    <div class="glass-card rounded-2xl p-6 shadow-lg">
        <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
                <h2 class="text-xl font-semibold text-gray-900">Manajemen Jadwal</h2>
                <p class="text-sm text-gray-500">Kelola jadwal otomatis wiper</p>
            </div>
            <div class="flex items-center gap-2 text-sm text-gray-500 bg-blue-50 px-4 py-2 rounded-xl">
                <i class="fa-solid fa-info-circle text-blue-500"></i>
                <span>Jadwal dikontrol melalui aplikasi mobile</span>
            </div>
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">
        @php
        $pendingCount = $schedules->where('status', 'pending')->count();
        $completedCount = $schedules->where('status', 'completed')->count();
        $triggeredCount = $schedules->where('status', 'triggered')->count();
        $cancelledCount = $schedules->where('status', 'cancelled')->count();
        @endphp

        <div class="glass-card rounded-xl p-4 shadow-md">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-lg bg-yellow-100 flex items-center justify-center">
                    <i class="fa-solid fa-hourglass-half text-yellow-600"></i>
                </div>
                <div>
                    <p class="text-2xl font-bold text-gray-900">{{ $pendingCount }}</p>
                    <p class="text-xs text-gray-500">Menunggu</p>
                </div>
            </div>
        </div>

        <div class="glass-card rounded-xl p-4 shadow-md">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
                    <i class="fa-solid fa-spinner text-blue-600"></i>
                </div>
                <div>
                    <p class="text-2xl font-bold text-gray-900">{{ $triggeredCount }}</p>
                    <p class="text-xs text-gray-500">Berjalan</p>
                </div>
            </div>
        </div>

        <div class="glass-card rounded-xl p-4 shadow-md">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-lg bg-green-100 flex items-center justify-center">
                    <i class="fa-solid fa-check text-green-600"></i>
                </div>
                <div>
                    <p class="text-2xl font-bold text-gray-900">{{ $completedCount }}</p>
                    <p class="text-xs text-gray-500">Selesai</p>
                </div>
            </div>
        </div>

        <div class="glass-card rounded-xl p-4 shadow-md">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-lg bg-red-100 flex items-center justify-center">
                    <i class="fa-solid fa-ban text-red-600"></i>
                </div>
                <div>
                    <p class="text-2xl font-bold text-gray-900">{{ $cancelledCount }}</p>
                    <p class="text-xs text-gray-500">Dibatalkan</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Schedule List -->
    <div class="glass-card rounded-2xl shadow-lg overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full">
                <thead>
                    <tr class="bg-gray-50 border-b border-gray-100">
                        <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Tanggal</th>
                        <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Waktu</th>
                        <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Durasi</th>
                        <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Status</th>
                        <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Dibuat</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    @forelse($schedules as $schedule)
                    <tr class="hover:bg-gray-50 transition-colors">
                        <td class="px-6 py-4">
                            <div class="flex items-center gap-3">
                                <div class="w-12 h-12 rounded-xl bg-gradient-to-br from-primary-100 to-purple-100 flex flex-col items-center justify-center">
                                    <span class="text-xs font-medium text-primary-600">{{ $schedule->schedule_date->format('M') }}</span>
                                    <span class="text-lg font-bold text-gray-900">{{ $schedule->schedule_date->format('d') }}</span>
                                </div>
                                <div>
                                    <p class="text-sm font-semibold text-gray-900">{{ $schedule->schedule_date->translatedFormat('l') }}</p>
                                    <p class="text-xs text-gray-500">{{ $schedule->schedule_date->format('d F Y') }}</p>
                                </div>
                            </div>
                        </td>
                        <td class="px-6 py-4">
                            <div class="flex items-center gap-2">
                                <i class="fa-regular fa-clock text-gray-400"></i>
                                <span class="text-sm font-semibold text-gray-900">{{ $schedule->schedule_time_formatted }}</span>
                            </div>
                        </td>
                        <td class="px-6 py-4">
                            <span class="inline-flex items-center gap-1.5 px-3 py-1 text-xs font-medium rounded-full bg-gray-100 text-gray-700">
                                <i class="fa-solid fa-stopwatch"></i>
                                {{ $schedule->duration_minutes }} menit
                            </span>
                        </td>
                        <td class="px-6 py-4">
                            <span class="inline-flex items-center gap-1.5 px-3 py-1 text-xs font-medium rounded-full
                                @if($schedule->status === 'pending') bg-yellow-100 text-yellow-700
                                @elseif($schedule->status === 'triggered') bg-blue-100 text-blue-700
                                @elseif($schedule->status === 'completed') bg-green-100 text-green-700
                                @else bg-red-100 text-red-700
                                @endif">
                                @if($schedule->status === 'pending')
                                <i class="fa-solid fa-hourglass-half"></i>
                                @elseif($schedule->status === 'triggered')
                                <i class="fa-solid fa-spinner fa-spin"></i>
                                @elseif($schedule->status === 'completed')
                                <i class="fa-solid fa-check"></i>
                                @else
                                <i class="fa-solid fa-ban"></i>
                                @endif
                                {{ $schedule->status_label }}
                            </span>
                        </td>
                        <td class="px-6 py-4">
                            <p class="text-sm text-gray-600">{{ $schedule->created_at->format('d M Y') }}</p>
                            <p class="text-xs text-gray-400">{{ $schedule->created_at->format('H:i') }}</p>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="5" class="px-6 py-12 text-center">
                            <i class="fa-regular fa-calendar text-4xl text-gray-300 mb-3"></i>
                            <p class="text-gray-500">Belum ada jadwal yang dibuat</p>
                            <p class="text-xs text-gray-400 mt-1">Jadwal dapat dibuat melalui aplikasi mobile</p>
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        @if($schedules->hasPages())
        <div class="px-6 py-4 border-t border-gray-100">
            {{ $schedules->links() }}
        </div>
        @endif
    </div>
</div>
@endsection