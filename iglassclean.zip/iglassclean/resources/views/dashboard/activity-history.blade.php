@extends('layouts.app')

@section('title', 'Riwayat Aktivitas')
@section('page-title', 'Riwayat Aktivitas')

@section('content')
<div class="space-y-6">

    <!-- Header with date filter -->
    <div class="glass-card rounded-2xl p-6 shadow-lg">
        <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
                <h2 class="text-xl font-semibold text-gray-900">Log Aktivitas Sistem</h2>
                <p class="text-sm text-gray-500">Semua aktivitas yang tercatat dari ESP32</p>
            </div>
            <form method="GET" class="flex items-center gap-3">
                <div class="relative">
                    <input type="date"
                        name="date"
                        value="{{ $date }}"
                        class="pl-10 pr-4 py-2 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all"
                        onchange="this.form.submit()">
                    <i class="fa-regular fa-calendar absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"></i>
                </div>
            </form>
        </div>
    </div>

    <!-- Activity Timeline -->
    <div class="glass-card rounded-2xl p-6 shadow-lg">
        <div class="flow-root">
            <ul role="list" class="-mb-8">
                @forelse($logs as $index => $log)
                <li>
                    <div class="relative pb-8">
                        @if(!$loop->last)
                        <span class="absolute left-5 top-5 -ml-px h-full w-0.5 bg-gray-200" aria-hidden="true"></span>
                        @endif
                        <div class="relative flex items-start space-x-4">
                            <div class="relative">
                                <div class="w-10 h-10 rounded-full flex items-center justify-center ring-8 ring-white
                                    @if($log->action_color === 'green') bg-green-100 text-green-600
                                    @elseif($log->action_color === 'red') bg-red-100 text-red-600
                                    @elseif($log->action_color === 'blue') bg-blue-100 text-blue-600
                                    @elseif($log->action_color === 'purple') bg-purple-100 text-purple-600
                                    @elseif($log->action_color === 'indigo') bg-indigo-100 text-indigo-600
                                    @else bg-gray-100 text-gray-600
                                    @endif">
                                    @if($log->action_icon === 'play-circle')
                                    <i class="fa-solid fa-play text-sm"></i>
                                    @elseif($log->action_icon === 'stop-circle')
                                    <i class="fa-solid fa-stop text-sm"></i>
                                    @elseif($log->action_icon === 'hand-raised')
                                    <i class="fa-solid fa-hand text-sm"></i>
                                    @elseif($log->action_icon === 'calendar')
                                    <i class="fa-solid fa-calendar text-sm"></i>
                                    @elseif($log->action_icon === 'beaker')
                                    <i class="fa-solid fa-flask text-sm"></i>
                                    @elseif($log->action_icon === 'power')
                                    <i class="fa-solid fa-power-off text-sm"></i>
                                    @elseif($log->action_icon === 'adjustments-horizontal')
                                    <i class="fa-solid fa-sliders text-sm"></i>
                                    @elseif($log->action_icon === 'cloud-rain')
                                    <i class="fa-solid fa-cloud-rain text-sm"></i>
                                    @else
                                    <i class="fa-solid fa-info text-sm"></i>
                                    @endif
                                </div>
                            </div>
                            <div class="flex-1 min-w-0">
                                <div class="flex items-center justify-between">
                                    <div>
                                        <p class="text-sm font-semibold text-gray-900">{{ $log->action_label }}</p>
                                        <p class="text-xs text-gray-500 mt-0.5">
                                            <span class="inline-flex items-center gap-1">
                                                <i class="fa-solid fa-microchip"></i>
                                                {{ ucfirst($log->source) }}
                                            </span>
                                        </p>
                                    </div>
                                    <div class="text-right">
                                        <p class="text-sm font-medium text-gray-900">{{ $log->created_at->format('H:i:s') }}</p>
                                        <p class="text-xs text-gray-400">{{ $log->created_at->format('d M Y') }}</p>
                                    </div>
                                </div>
                                @if($log->details)
                                <div class="mt-2 p-3 bg-gray-50 rounded-lg">
                                    <p class="text-sm text-gray-600">{{ $log->details }}</p>
                                </div>
                                @endif
                            </div>
                        </div>
                    </div>
                </li>
                @empty
                <li>
                    <div class="text-center py-12">
                        <i class="fa-solid fa-clock-rotate-left text-4xl text-gray-300 mb-3"></i>
                        <p class="text-gray-500">Tidak ada aktivitas untuk tanggal ini</p>
                    </div>
                </li>
                @endforelse
            </ul>
        </div>

        <!-- Pagination -->
        @if($logs->hasPages())
        <div class="mt-8 pt-6 border-t border-gray-100">
            {{ $logs->appends(['date' => $date])->links() }}
        </div>
        @endif
    </div>
</div>
@endsection