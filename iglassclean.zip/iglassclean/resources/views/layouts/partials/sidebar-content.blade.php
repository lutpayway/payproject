<!-- Logo -->
<div class="flex h-16 shrink-0 items-center">
    <div class="flex items-center gap-3">
        <img src="{{ asset('images/Logo_iGlassClean.png') }}" alt="iGlass Clean Logo" class="w-12 h-20 rounded-xl object-contain">
        <div>
            <h1 class="text-white font-bold text-xl">iGlass Clean</h1>
            <p class="text-white/60 text-xs">Smart Wiper System</p>
        </div>
    </div>
</div>

<!-- Navigation -->
<nav class="flex flex-1 flex-col">
    <ul role="list" class="flex flex-1 flex-col gap-y-7">
        <li>
            <ul role="list" class="-mx-2 space-y-1">
                <!-- Dashboard -->
                <li>
                    <a href="{{ route('dashboard') }}"
                        class="group flex gap-x-3 rounded-lg p-3 text-sm font-medium leading-6 {{ request()->routeIs('dashboard') ? 'bg-white/20 text-white' : 'text-white/70 hover:text-white hover:bg-white/10' }} transition-all duration-200">
                        <i class="fa-solid fa-gauge-high text-lg w-6 text-center"></i>
                        Dashboard
                    </a>
                </li>

                <!-- Sensor History -->
                <li>
                    <a href="{{ route('sensor.history') }}"
                        class="group flex gap-x-3 rounded-lg p-3 text-sm font-medium leading-6 {{ request()->routeIs('sensor.history') ? 'bg-white/20 text-white' : 'text-white/70 hover:text-white hover:bg-white/10' }} transition-all duration-200">
                        <i class="fa-solid fa-chart-line text-lg w-6 text-center"></i>
                        Riwayat Sensor
                    </a>
                </li>

                <!-- Activity History -->
                <li>
                    <a href="{{ route('activity.history') }}"
                        class="group flex gap-x-3 rounded-lg p-3 text-sm font-medium leading-6 {{ request()->routeIs('activity.history') ? 'bg-white/20 text-white' : 'text-white/70 hover:text-white hover:bg-white/10' }} transition-all duration-200">
                        <i class="fa-solid fa-clock-rotate-left text-lg w-6 text-center"></i>
                        Riwayat Aktivitas
                    </a>
                </li>

                <!-- Schedules -->
                <li>
                    <a href="{{ route('schedules') }}"
                        class="group flex gap-x-3 rounded-lg p-3 text-sm font-medium leading-6 {{ request()->routeIs('schedules') ? 'bg-white/20 text-white' : 'text-white/70 hover:text-white hover:bg-white/10' }} transition-all duration-200">
                        <i class="fa-solid fa-calendar-days text-lg w-6 text-center"></i>
                        Jadwal
                    </a>
                </li>
            </ul>
        </li>

        <!-- Info section -->
        <li class="mt-auto">
            <div class="rounded-xl bg-white/10 p-4">
                <div class="flex items-center gap-3 mb-3">
                    <div class="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center">
                        <i class="fa-solid fa-microchip text-white text-sm"></i>
                    </div>
                    <div>
                        <p class="text-white text-sm font-medium">ESP32 Wiper</p>
                        <p class="text-white/60 text-xs">IoT Controller</p>
                    </div>
                </div>
                <div class="flex items-center gap-2 text-xs text-white/60">
                    <span class="relative flex h-2 w-2">
                        <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                        <span class="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
                    </span>
                    Terhubung via MQTT
                </div>
            </div>
        </li>
    </ul>
</nav>