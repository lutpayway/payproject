

<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('page-title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div x-data="dashboardData()" x-init="init()" class="space-y-6">

    <!-- Status Cards -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">

        <!-- Rain Status Card -->
        <div class="glass-card rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300">
            <div class="flex items-center justify-between mb-4">
                <div class="w-12 h-12 rounded-xl flex items-center justify-center"
                    :class="{
                         'bg-red-100': sensor.rain_status === 'DERAS',
                         'bg-yellow-100': sensor.rain_status === 'SEDANG',
                         'bg-green-100': sensor.rain_status === 'TIDAK_HUJAN' || !sensor.rain_status
                     }">
                    <i class="fa-solid fa-cloud-rain text-xl"
                        :class="{
                           'text-red-600': sensor.rain_status === 'DERAS',
                           'text-yellow-600': sensor.rain_status === 'SEDANG',
                           'text-green-600': sensor.rain_status === 'TIDAK_HUJAN' || !sensor.rain_status
                       }"></i>
                </div>
                <span class="px-3 py-1 text-xs font-medium rounded-full"
                    :class="{
                          'bg-red-100 text-red-700': sensor.rain_status === 'DERAS',
                          'bg-yellow-100 text-yellow-700': sensor.rain_status === 'SEDANG',
                          'bg-green-100 text-green-700': sensor.rain_status === 'TIDAK_HUJAN' || !sensor.rain_status
                      }"
                    x-text="sensor.rain_status_label || 'Tidak Ada Data'">
                </span>
            </div>
            <div>
                <p class="text-sm text-gray-500 mb-1">Intensitas Hujan</p>
                <div class="flex items-end gap-2">
                    <span class="text-3xl font-bold text-gray-900" x-text="sensor.rain_value || '0'"></span>
                    <span class="text-sm text-gray-500 mb-1">/ 4095</span>
                </div>
            </div>
            <!-- Progress bar -->
            <div class="mt-4 h-2 bg-gray-100 rounded-full overflow-hidden">
                <div class="h-full rounded-full transition-all duration-500"
                    :class="{
                         'bg-red-500': sensor.rain_status === 'DERAS',
                         'bg-yellow-500': sensor.rain_status === 'SEDANG',
                         'bg-green-500': sensor.rain_status === 'TIDAK_HUJAN' || !sensor.rain_status
                     }"
                    :style="'width: ' + sensor.rain_intensity + '%'">
                </div>
            </div>
        </div>

        <!-- Servo Status Card -->
        <div class="glass-card rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300">
            <div class="flex items-center justify-between mb-4">
                <div class="w-12 h-12 rounded-xl flex items-center justify-center"
                    :class="sensor.servo_status === 'ON' ? 'bg-blue-100' : 'bg-gray-100'">
                    <i class="fa-solid fa-gear text-xl"
                        :class="[sensor.servo_status === 'ON' ? 'text-blue-600 servo-animation' : 'text-gray-400']"></i>
                </div>
                <span class="px-3 py-1 text-xs font-medium rounded-full"
                    :class="sensor.servo_status === 'ON' ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-600'">
                    <span x-text="sensor.servo_status || 'OFF'"></span>
                </span>
            </div>
            <div>
                <p class="text-sm text-gray-500 mb-1">Status Wiper</p>
                <p class="text-2xl font-bold text-gray-900" x-text="sensor.servo_status === 'ON' ? 'Aktif' : 'Nonaktif'"></p>
            </div>
            <div class="mt-4 flex items-center gap-2 text-sm text-gray-500">
                <i class="fa-solid fa-clock"></i>
                <span x-text="'Update: ' + (sensor.created_at || '-')"></span>
            </div>
        </div>

        <!-- Today's Statistics -->
        <div class="glass-card rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300">
            <div class="flex items-center justify-between mb-4">
                <div class="w-12 h-12 rounded-xl bg-purple-100 flex items-center justify-center">
                    <i class="fa-solid fa-chart-simple text-xl text-purple-600"></i>
                </div>
                <span class="text-xs text-gray-500">Hari Ini</span>
            </div>
            <div>
                <p class="text-sm text-gray-500 mb-1">Total Pembacaan</p>
                <p class="text-3xl font-bold text-gray-900"><?php echo e(number_format($stats['today_sensor_count'])); ?></p>
            </div>
            <div class="mt-4 grid grid-cols-3 gap-2 text-xs">
                <div class="text-center p-2 bg-red-50 rounded-lg">
                    <p class="font-semibold text-red-600"><?php echo e($stats['rain_stats']['DERAS'] ?? 0); ?></p>
                    <p class="text-red-400">Deras</p>
                </div>
                <div class="text-center p-2 bg-yellow-50 rounded-lg">
                    <p class="font-semibold text-yellow-600"><?php echo e($stats['rain_stats']['SEDANG'] ?? 0); ?></p>
                    <p class="text-yellow-500">Sedang</p>
                </div>
                <div class="text-center p-2 bg-green-50 rounded-lg">
                    <p class="font-semibold text-green-600"><?php echo e($stats['rain_stats']['TIDAK_HUJAN'] ?? 0); ?></p>
                    <p class="text-green-400">Cerah</p>
                </div>
            </div>
        </div>

        <!-- Wiper Running Time -->
        <div class="glass-card rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300">
            <div class="flex items-center justify-between mb-4">
                <div class="w-12 h-12 rounded-xl bg-indigo-100 flex items-center justify-center">
                    <i class="fa-solid fa-stopwatch text-xl text-indigo-600"></i>
                </div>
                <span class="text-xs text-gray-500">Hari Ini</span>
            </div>
            <div>
                <p class="text-sm text-gray-500 mb-1">Waktu Wiper Aktif</p>
                <div class="flex items-end gap-2">
                    <span class="text-3xl font-bold text-gray-900"><?php echo e($stats['servo_running_minutes']); ?></span>
                    <span class="text-sm text-gray-500 mb-1">menit</span>
                </div>
            </div>
            <div class="mt-4 flex items-center gap-2 text-sm text-gray-500">
                <i class="fa-solid fa-bolt text-indigo-500"></i>
                <span><?php echo e($stats['today_activity_count']); ?> aktivitas tercatat</span>
            </div>
        </div>
    </div>

    <!-- Charts & Activity Section -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">

        <!-- Sensor Chart -->
        <div class="lg:col-span-2 glass-card rounded-2xl p-6 shadow-lg">
            <div class="flex items-center justify-between mb-6">
                <div>
                    <h3 class="text-lg font-semibold text-gray-900">Grafik Sensor</h3>
                    <p class="text-sm text-gray-500">Data pembacaan sensor 1 jam terakhir</p>
                </div>
                <div class="flex items-center gap-2">
                    <button @click="loadChartData(1)"
                        :class="chartHours === 1 ? 'bg-primary-600 text-white' : 'bg-gray-100 text-gray-600'"
                        class="px-3 py-1.5 text-xs font-medium rounded-lg transition-colors">
                        1 Jam
                    </button>
                    <button @click="loadChartData(6)"
                        :class="chartHours === 6 ? 'bg-primary-600 text-white' : 'bg-gray-100 text-gray-600'"
                        class="px-3 py-1.5 text-xs font-medium rounded-lg transition-colors">
                        6 Jam
                    </button>
                    <button @click="loadChartData(24)"
                        :class="chartHours === 24 ? 'bg-primary-600 text-white' : 'bg-gray-100 text-gray-600'"
                        class="px-3 py-1.5 text-xs font-medium rounded-lg transition-colors">
                        24 Jam
                    </button>
                </div>
            </div>
            <div class="h-72">
                <canvas id="sensorChart"></canvas>
            </div>
        </div>

        <!-- Recent Activity -->
        <div class="glass-card rounded-2xl p-6 shadow-lg">
            <div class="flex items-center justify-between mb-6">
                <div>
                    <h3 class="text-lg font-semibold text-gray-900">Aktivitas Terbaru</h3>
                    <p class="text-sm text-gray-500">10 aktivitas terakhir</p>
                </div>
                <a href="<?php echo e(route('activity.history')); ?>" class="text-primary-600 hover:text-primary-700 text-sm font-medium">
                    Lihat Semua →
                </a>
            </div>
            <div class="space-y-4 max-h-80 overflow-y-auto pr-2">
                <?php $__empty_1 = true; $__currentLoopData = $recentActivities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="flex items-start gap-3 p-3 rounded-xl hover:bg-gray-50 transition-colors">
                    <div class="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0
                                <?php if($activity->action_color === 'green'): ?> bg-green-100 text-green-600
                                <?php elseif($activity->action_color === 'red'): ?> bg-red-100 text-red-600
                                <?php elseif($activity->action_color === 'blue'): ?> bg-blue-100 text-blue-600
                                <?php elseif($activity->action_color === 'purple'): ?> bg-purple-100 text-purple-600
                                <?php else: ?> bg-gray-100 text-gray-600
                                <?php endif; ?>">
                        <?php if($activity->action_icon === 'play-circle'): ?>
                        <i class="fa-solid fa-play text-sm"></i>
                        <?php elseif($activity->action_icon === 'stop-circle'): ?>
                        <i class="fa-solid fa-stop text-sm"></i>
                        <?php elseif($activity->action_icon === 'hand-raised'): ?>
                        <i class="fa-solid fa-hand text-sm"></i>
                        <?php elseif($activity->action_icon === 'calendar'): ?>
                        <i class="fa-solid fa-calendar text-sm"></i>
                        <?php elseif($activity->action_icon === 'beaker'): ?>
                        <i class="fa-solid fa-flask text-sm"></i>
                        <?php elseif($activity->action_icon === 'power'): ?>
                        <i class="fa-solid fa-power-off text-sm"></i>
                        <?php elseif($activity->action_icon === 'cloud-rain'): ?>
                        <i class="fa-solid fa-cloud-rain text-sm"></i>
                        <?php else: ?>
                        <i class="fa-solid fa-info text-sm"></i>
                        <?php endif; ?>
                    </div>
                    <div class="flex-1 min-w-0">
                        <p class="text-sm font-medium text-gray-900"><?php echo e($activity->action_label); ?></p>
                        <?php if($activity->details): ?>
                        <p class="text-xs text-gray-500 truncate"><?php echo e($activity->details); ?></p>
                        <?php endif; ?>
                        <p class="text-xs text-gray-400 mt-1"><?php echo e($activity->created_at->format('H:i:s')); ?></p>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="text-center py-8">
                    <i class="fa-solid fa-inbox text-4xl text-gray-300 mb-3"></i>
                    <p class="text-gray-500">Belum ada aktivitas</p>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Schedules & Weekly Chart -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">

        <!-- Pending Schedules -->
        <div class="glass-card rounded-2xl p-6 shadow-lg">
            <div class="flex items-center justify-between mb-6">
                <div>
                    <h3 class="text-lg font-semibold text-gray-900">Jadwal Mendatang</h3>
                    <p class="text-sm text-gray-500">Jadwal wiper yang belum dijalankan</p>
                </div>
                <a href="<?php echo e(route('schedules')); ?>" class="text-primary-600 hover:text-primary-700 text-sm font-medium">
                    Kelola →
                </a>
            </div>
            <div class="space-y-3">
                <?php $__empty_1 = true; $__currentLoopData = $pendingSchedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="flex items-center justify-between p-4 bg-gradient-to-r from-primary-50 to-purple-50 rounded-xl border border-primary-100">
                    <div class="flex items-center gap-4">
                        <div class="w-12 h-12 rounded-xl bg-white shadow-sm flex flex-col items-center justify-center">
                            <span class="text-xs font-medium text-primary-600"><?php echo e($schedule->schedule_date->format('M')); ?></span>
                            <span class="text-lg font-bold text-gray-900"><?php echo e($schedule->schedule_date->format('d')); ?></span>
                        </div>
                        <div>
                            <p class="font-medium text-gray-900"><?php echo e($schedule->schedule_date->format('l')); ?></p>
                            <p class="text-sm text-gray-500">
                                <i class="fa-regular fa-clock mr-1"></i>
                                <?php echo e($schedule->schedule_time_formatted); ?>

                                <span class="text-gray-400">•</span>
                                <?php echo e($schedule->duration_minutes); ?> menit
                            </p>
                        </div>
                    </div>
                    <span class="px-3 py-1 text-xs font-medium rounded-full bg-yellow-100 text-yellow-700">
                        <?php echo e($schedule->status_label); ?>

                    </span>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="text-center py-8">
                    <i class="fa-regular fa-calendar text-4xl text-gray-300 mb-3"></i>
                    <p class="text-gray-500">Tidak ada jadwal mendatang</p>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Weekly Statistics -->
        <div class="glass-card rounded-2xl p-6 shadow-lg">
            <div class="flex items-center justify-between mb-6">
                <div>
                    <h3 class="text-lg font-semibold text-gray-900">Statistik Mingguan</h3>
                    <p class="text-sm text-gray-500">Aktivitas wiper 7 hari terakhir</p>
                </div>
            </div>
            <div class="h-56">
                <canvas id="weeklyChart"></canvas>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<div id="dashboard-config"
    data-sensor='<?php echo json_encode($initialSensorData, 15, 512) ?>'
    data-weekly='<?php echo json_encode($stats["last_7_days"], 15, 512) ?>'
    data-api-realtime="<?php echo e(url('/api/realtime.php')); ?>"
    data-api-chart="<?php echo e(url('/api/chart.php')); ?>"
    style="display:none;"></div>
<script src="<?php echo e(asset('js/dashboard.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\iglassclean\resources\views/dashboard/index.blade.php ENDPATH**/ ?>